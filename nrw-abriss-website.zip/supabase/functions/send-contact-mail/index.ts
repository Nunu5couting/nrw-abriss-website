import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { name, email, phone, message, project_type } = await req.json()

    // Validate required fields
    if (!name || !email || !message) {
      return new Response(
        JSON.stringify({ error: 'Name, email, and message are required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Insert contact into database
    const { data: contactData, error: contactError } = await supabaseClient
      .from('contacts')
      .insert([
        {
          name,
          email,
          phone: phone || null,
          message,
          project_type: project_type || 'Kontaktanfrage'
        }
      ])
      .select()

    if (contactError) {
      console.error('Database error:', contactError)
      return new Response(
        JSON.stringify({ error: 'Failed to save contact form' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Send email notification (if SMTP is configured)
    const smtpHost = Deno.env.get('SMTP_HOST')
    const smtpUser = Deno.env.get('SMTP_USER')
    const smtpPass = Deno.env.get('SMTP_PASS')

    if (smtpHost && smtpUser && smtpPass) {
      try {
        // Here you would implement actual email sending
        // For now, we'll just log the email content
        console.log('Email notification would be sent:', {
          to: 'info@nrw-abriss.de',
          subject: `Neue Kontaktanfrage von ${name}`,
          body: `
            Name: ${name}
            Email: ${email}
            Telefon: ${phone || 'Nicht angegeben'}
            Projekttyp: ${project_type || 'Kontaktanfrage'}
            
            Nachricht:
            ${message}
          `
        })
      } catch (emailError) {
        console.error('Email sending error:', emailError)
        // Don't fail the request if email sending fails
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Contact form submitted successfully',
        data: contactData[0]
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Function error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})
