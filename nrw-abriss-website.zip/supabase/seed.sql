-- Seed data for NRW Abriss Database
-- Insert sample data for development and testing

-- Insert sample testimonials
INSERT INTO testimonials (name, role, company, content, rating, is_featured) VALUES
('Michael Schmidt', 'Geschäftsführer', 'Schmidt Bau GmbH', 'NRW Abriss hat unsere Abbrucharbeiten professionell und termingerecht durchgeführt. Sehr zu empfehlen!', 5, true),
('Sarah Weber', 'Projektleiterin', 'Weber Immobilien', 'Hervorragende Arbeit bei der Entkernung unseres Bürogebäudes. Sauber, schnell und zuverlässig.', 5, true),
('Thomas Müller', 'Eigentümer', 'Müller & Söhne', 'Die Zusammenarbeit war sehr angenehm. Alles wurde wie besprochen umgesetzt.', 4, true),
('Lisa Klein', 'Architektin', 'Klein Architekten', 'Professionelle Durchführung der Abbrucharbeiten. Sehr zufrieden mit dem Ergebnis.', 5, false),
('Andreas Groß', 'Bauleiter', 'Groß Bau AG', 'Schnelle und saubere Arbeit. Gerne wieder!', 4, false);

-- Insert sample projects
INSERT INTO projects (title, description, project_type, location, completed_at, is_featured) VALUES
('Bürogebäude Entkernung', 'Vollständige Entkernung eines 3-stöckigen Bürogebäudes in Köln', 'Entkernung', 'Köln', '2024-01-15', true),
('Wohnhaus Abbruch', 'Kompletter Abbruch eines Einfamilienhauses mit Keller', 'Wohnhaus', 'Düsseldorf', '2024-02-20', true),
('Industriehalle Demontage', 'Demontage einer Industriehalle mit Kranarbeiten', 'Industrie', 'Essen', '2024-03-10', true),
('Schadstoffsanierung', 'Entfernung von Asbest und anderen Schadstoffen', 'Sanierung', 'Duisburg', '2024-04-05', false),
('Grundstücksberäumung', 'Beräumung eines Baugrundstücks von Altlasten', 'Beräumung', 'Wuppertal', '2024-04-20', false);

-- Insert sample services
INSERT INTO services (title, description, icon, order_index, is_active) VALUES
('Moderne Technik', 'Unser spezialisiertes Team wird regelmäßig geschult. So garantieren wir einen sicheren Abbruch. Durch verschiedene Techniken stellen wir sicher, dass benachbarte Objekte und Personen nicht von Staub, Schmutz und Lärm betroffen werden.', 'Shield', 1, true),
('Innenraum-Abbruch', 'Spezialisierte Innenraum-Abbrucharbeiten mit höchster Präzision und Sorgfalt für Ihr Projekt. Wir garantieren saubere und effiziente Arbeiten.', 'Users', 2, true),
('Effektive Abläufe', 'Routinierte Abläufe und erstklassiger Service für termingerechte und budgetgerechte Umsetzung Ihrer Abbrucharbeiten.', 'CheckCircle', 3, true),
('Sorgfältige Entsorgung', 'Ziel unserer Abfallwirtschaft ist es die Umwelt möglichst wenig zu beeinträchtigen und gleichzeitig den höchsten Nutzen aus den Abfällen zu ziehen. Das heißt wertvolle Rohstoffe zu erhalten und wiederzuverwerten.', 'Recycle', 4, true);

-- Insert sample admin user (password: admin123)
-- Note: In production, use Supabase Auth to create users
INSERT INTO users (email, role) VALUES
('admin@nrw-abriss.de', 'admin');

-- Insert sample newsletter subscribers
INSERT INTO newsletter_subscribers (email) VALUES
('test@example.com'),
('newsletter@test.de'),
('info@sample.org');
