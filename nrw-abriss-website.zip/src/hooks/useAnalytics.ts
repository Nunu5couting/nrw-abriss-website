import { useEffect } from 'react'
import { supabase } from '@/lib/supabase'

export function useAnalytics() {
  useEffect(() => {
    const trackPageView = async () => {
      try {
        const page = window.location.pathname
        const referrer = document.referrer || 'direct'
        
        await supabase
          .from('visitor_logs')
          .insert([
            {
              page_visited: page,
              referrer: referrer,
              user_agent: navigator.userAgent
            }
          ])
      } catch (error) {
        console.error('Analytics tracking error:', error)
      }
    }

    // Track initial page view
    trackPageView()

    // Track page changes (for SPA navigation)
    const handleRouteChange = () => {
      trackPageView()
    }

    // Listen for popstate events (back/forward navigation)
    window.addEventListener('popstate', handleRouteChange)

    return () => {
      window.removeEventListener('popstate', handleRouteChange)
    }
  }, [])
}
