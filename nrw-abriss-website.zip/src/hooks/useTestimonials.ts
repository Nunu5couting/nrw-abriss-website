import { useState, useEffect } from 'react'
import { supabase, Testimonial } from '@/lib/supabase'

export function useTestimonials() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchTestimonials()
  }, [])

  const fetchTestimonials = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('testimonials')
        .select('*')
        .eq('is_featured', true)
        .order('created_at', { ascending: false })

      if (error) {
        setError(error.message)
      } else {
        setTestimonials(data || [])
      }
    } catch (err) {
      setError('Failed to fetch testimonials')
    } finally {
      setLoading(false)
    }
  }

  return { testimonials, loading, error, refetch: fetchTestimonials }
}
