import { useState, useEffect } from 'react'
import { supabase, Service } from '@/lib/supabase'

export function useServices() {
  const [services, setServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchServices()
  }, [])

  const fetchServices = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .eq('is_active', true)
        .order('order_index', { ascending: true })

      if (error) {
        setError(error.message)
      } else {
        setServices(data || [])
      }
    } catch (err) {
      setError('Failed to fetch services')
    } finally {
      setLoading(false)
    }
  }

  return { services, loading, error, refetch: fetchServices }
}
