import { NextRequest, NextResponse } from 'next/server'
import { supabase, isSupabaseConfigured } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, phone, message, project_type } = body

    // Validate required fields
    if (!name || !email || !message) {
      return NextResponse.json(
        { error: 'Name, email, and message are required' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email format' },
        { status: 400 }
      )
    }

    // Demo mode handling
    if (!isSupabaseConfigured) {
      console.log('Demo mode: Contact form submission:', { name, email, phone, message, project_type })
      return NextResponse.json(
        { 
          success: true, 
          message: 'Contact form submitted successfully (demo mode)',
          demo: true
        },
        { status: 200 }
      )
    }

    // Insert contact into database
    const { data, error } = await supabase
      .from('contacts')
      .insert([
        {
          name,
          email,
          phone: phone || null,
          message,
          project_type: project_type || 'Kontaktanfrage'
        }
      ])
      .select()

    if (error) {
      console.error('Database error:', error)
      return NextResponse.json(
        { error: 'Failed to save contact form' },
        { status: 500 }
      )
    }

    // Log visitor information
    const ip = request.headers.get('x-forwarded-for') || 
               request.headers.get('x-real-ip') || 
               'unknown'
    
    await supabase
      .from('visitor_logs')
      .insert([
        {
          ip_address: ip,
          user_agent: request.headers.get('user-agent'),
          page_visited: '/contact',
          referrer: request.headers.get('referer')
        }
      ])

    return NextResponse.json(
      { 
        success: true, 
        message: 'Contact form submitted successfully',
        data: data[0]
      },
      { status: 200 }
    )

  } catch (error) {
    console.error('API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
