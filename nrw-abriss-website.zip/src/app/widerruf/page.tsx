import Link from "next/link";

export default function WiderrufPage() {
  return (
    <div className="min-h-screen bg-[#030303] text-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-rose-400 via-white/90 to-white/70 bg-clip-text text-transparent">
          Widerrufsrecht
        </h1>
        
        <div className="space-y-8 text-white/80">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Widerrufsbelehrung</h2>
            
            <h3 className="text-xl font-semibold text-white mt-4 mb-2">Widerrufsrecht</h3>
            <p className="mb-4">
              Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen.
            </p>
            <p className="mb-4">
              Die Widerrufsfrist beträgt vierzehn Tage ab dem Tag des Vertragsabschlusses.
            </p>
            <p className="mb-4">
              Um Ihr Widerrufsrecht auszuüben, müssen Sie uns (NRW Abriss GmbH, Gotenring 18, 50679 Köln, Deutschland, Tel.: 0221/29491092, E-Mail: info@nrw-abriss.de) mittels einer eindeutigen Erklärung (z. B. ein mit der Post versandter Brief, Telefax oder E-Mail) über Ihren Entschluss, diesen Vertrag zu widerrufen, informieren. Sie können dafür das beigefügte Muster-Widerrufsformular verwenden, das jedoch nicht vorgeschrieben ist.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Folgen des Widerrufs</h2>
            <p className="mb-4">
              Wenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen, die wir von Ihnen erhalten haben, einschließlich der Lieferkosten (mit Ausnahme der zusätzlichen Kosten, die daraus resultieren, dass Sie eine andere Art der Lieferung als die von uns angebotene, günstigste Standardlieferung gewählt haben), unverzüglich und spätestens binnen vierzehn Tagen ab dem Tag zurückzuzahlen, an dem die Mitteilung über Ihren Widerruf dieses Vertrags bei uns eingegangen ist.
            </p>
            <p className="mb-4">
              Für diese Rückzahlung verwenden wir dasselbe Zahlungsmittel, das Sie bei der ursprünglichen Transaktion eingesetzt haben, es sei denn, mit Ihnen wurde ausdrücklich etwas anderes vereinbart; in keinem Fall werden Ihnen wegen dieser Rückzahlung Entgelte berechnet.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Besondere Hinweise</h2>
            <p className="mb-4">
              Ihr Widerrufsrecht erlischt vorzeitig, wenn der Vertrag von beiden Seiten vollständig erfüllt ist, bevor Sie Ihr Widerrufsrecht ausgeübt haben.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Muster-Widerrufsformular</h2>
            <p className="mb-4">(Wenn Sie den Vertrag widerrufen wollen, dann füllen Sie bitte dieses Formular aus und senden Sie es zurück.)</p>
            <div className="bg-white/5 border border-white/10 rounded-lg p-6 mb-4">
              <p className="mb-2">An: NRW Abriss GmbH</p>
              <p className="mb-2">Gotenring 18</p>
              <p className="mb-2">50679 Köln</p>
              <p className="mb-2">Deutschland</p>
              <p className="mb-4">E-Mail: info@nrw-abriss.de</p>
              
              <p className="mb-4">Hiermit widerrufe(n) ich/wir (*) den von mir/uns (*) abgeschlossenen Vertrag über den Kauf der folgenden Waren (*)/die Erbringung der folgenden Dienstleistung (*)</p>
              
              <p className="mb-2">Bestellt am (*)/erhalten am (*)</p>
              <p className="mb-2">Name des/der Verbraucher(s)</p>
              <p className="mb-2">Anschrift des/der Verbraucher(s)</p>
              <p className="mb-2">Unterschrift des/der Verbraucher(s) (nur bei Mitteilung auf Papier)</p>
              <p className="mb-2">Datum</p>
              <p className="text-sm text-white/60">(*) Unzutreffendes streichen.</p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Ende der Widerrufsbelehrung</h2>
          </section>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10">
          <Link href="/" className="text-rose-400 hover:text-rose-500 transition-colors" aria-label="Zurück zur Startseite">
            &larr; Zurück zur Startseite
          </Link>
        </div>
      </div>
    </div>
  );
}




