import Link from "next/link";

export default function CookiesPage() {
  return (
    <div className="min-h-screen bg-[#030303] text-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-rose-400 via-white/90 to-white/70 bg-clip-text text-transparent">
          Cookie-Richtlinie
        </h1>
        
        <div className="space-y-8 text-white/80">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">1. Allgemeine Informationen zu Cookies</h2>
            <p className="mb-4">
              Diese Website verwendet Cookies, um Ihnen das bestmögliche Erlebnis zu bieten. Cookies sind kleine Textdateien, die auf Ihrem Gerät gespeichert werden, wenn Sie unsere Website besuchen.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">2. Welche Cookies verwenden wir?</h2>
            
            <h3 className="text-xl font-semibold text-white mt-4 mb-2">Notwendige Cookies</h3>
            <p className="mb-4">
              Diese Cookies sind für das Funktionieren der Website unbedingt erforderlich. Sie ermöglichen grundlegende Funktionen wie Seitennavigation und Zugriff auf sichere Bereiche der Website. Die Website kann ohne diese Cookies nicht ordnungsgemäß funktionieren.
            </p>

            <h3 className="text-xl font-semibold text-white mt-4 mb-2">Funktionale Cookies</h3>
            <p className="mb-4">
              Diese Cookies ermöglichen es der Website, erweiterte Funktionalität und Personalisierung bereitzustellen. Sie können von uns oder von Drittanbietern gesetzt werden, deren Dienste wir auf unseren Seiten verwenden.
            </p>

            <h3 className="text-xl font-semibold text-white mt-4 mb-2">Analyse-Cookies</h3>
            <p className="mb-4">
              Diese Cookies helfen uns zu verstehen, wie Besucher mit unserer Website interagieren, indem sie Informationen anonym sammeln und melden. Dies hilft uns, unsere Website zu verbessern.
            </p>

            <h3 className="text-xl font-semibold text-white mt-4 mb-2">Marketing-Cookies</h3>
            <p className="mb-4">
              Diese Cookies werden verwendet, um Besuchern auf Websites zu folgen. Die Absicht ist, Anzeigen zu zeigen, die relevant und ansprechend für den einzelnen Benutzer sind und daher wertvoller für Publisher und werbetreibende Drittanbieter sind.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">3. Drittanbieter-Cookies</h2>
            <p className="mb-4">
              In einigen besonderen Fällen verwenden wir auch Cookies, die von vertrauenswürdigen Dritten bereitgestellt werden. Im Folgenden erfahren Sie, auf welche Drittanbieter-Cookies Sie auf dieser Website stoßen könnten.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">4. Wie können Sie Cookies kontrollieren?</h2>
            <p className="mb-4">
              Sie können Cookies in Ihren Browser-Einstellungen kontrollieren und/oder löschen. Sie können alle Cookies auf Ihrem Computer löschen und die meisten Browser so einstellen, dass sie verhindern, dass Cookies darauf platziert werden.
            </p>
            <p className="mb-4">
              Wenn Sie dies tun, müssen Sie jedoch möglicherweise bei jedem Besuch manuell einige Einstellungen anpassen, und einige Dienste und Funktionen funktionieren möglicherweise nicht.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">5. Änderungen dieser Cookie-Richtlinie</h2>
            <p className="mb-4">
              Wir können diese Cookie-Richtlinie von Zeit zu Zeit aktualisieren, um Änderungen an den verwendeten Cookies oder aus anderen operativen, rechtlichen oder regulatorischen Gründen widerzuspiegeln. Bitte besuchen Sie diese Cookie-Richtlinie daher regelmäßig, um auf dem neuesten Stand zu bleiben.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">6. Weitere Informationen</h2>
            <p className="mb-4">
              Wenn Sie Fragen zu unserer Verwendung von Cookies oder anderen Technologien haben, kontaktieren Sie uns bitte unter:
            </p>
            <p className="mb-2">NRW Abriss GmbH</p>
            <p className="mb-2">Gotenring 18</p>
            <p className="mb-2">50679 Köln</p>
            <p className="mb-2">Deutschland</p>
            <p className="mb-2">Tel.: 0221/29491092</p>
            <p className="mb-4">E-Mail: info@nrw-abriss.de</p>
          </section>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10">
          <Link href="/" className="text-rose-400 hover:text-rose-500 transition-colors" aria-label="Zurück zur Startseite">
            &larr; Zurück zur Startseite
          </Link>
        </div>
      </div>
    </div>
  );
}




