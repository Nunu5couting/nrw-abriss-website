import Link from "next/link";

export default function AGBPage() {
  return (
    <div className="min-h-screen bg-[#030303] text-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-rose-400 via-white/90 to-white/70 bg-clip-text text-transparent">
          Allgemeine Geschäftsbedingungen
        </h1>
        
        <div className="space-y-8 text-white/80">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">1. Geltungsbereich</h2>
            <p className="mb-4">
              Diese Allgemeinen Geschäftsbedingungen gelten für alle Verträge über Abbrucharbeiten, Entsorgungsleistungen und damit zusammenhängende Dienstleistungen zwischen der NRW Abriss GmbH (nachfolgend &quot;Auftragnehmer&quot;) und ihren Kunden (nachfolgend &quot;Auftraggeber&quot;).
            </p>
            <p className="mb-4">
              Abweichende, entgegenstehende oder ergänzende AGB des Auftraggebers werden nicht Vertragsbestandteil, es sei denn, ihrer Geltung wird ausdrücklich schriftlich zugestimmt.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">2. Vertragsabschluss und Vertragsgegenstand</h2>
            <p className="mb-4">
              Der Vertrag kommt durch schriftliche Auftragsbestätigung des Auftragnehmers oder durch Ausführung des Auftrags zustande. Mündliche Nebenabreden bedürfen der schriftlichen Bestätigung.
            </p>
            <p className="mb-4">
              Vertragsgegenstand sind die in der Auftragsbestätigung oder im Auftrag beschriebenen Leistungen. Der Auftragnehmer erbringt Abbrucharbeiten, Entsorgungsleistungen und damit zusammenhängende Dienstleistungen nach bestem Wissen und Gewissen.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">3. Leistungen des Auftragnehmers</h2>
            <p className="mb-4">
              Der Auftragnehmer verpflichtet sich, die vereinbarten Leistungen fachgerecht, termingerecht und unter Beachtung der einschlägigen Vorschriften zu erbringen.
            </p>
            <p className="mb-4">
              Die Leistungen umfassen insbesondere:
            </p>
            <ul className="list-disc list-inside mb-4 space-y-2">
              <li>Abrissarbeiten verschiedenster Art</li>
              <li>Innenraum-Abbruch und Entkernung</li>
              <li>Schadstoffsanierung</li>
              <li>Umweltgerechte Entsorgung</li>
              <li>Recycling und Wiederverwertung von Materialien</li>
              <li>Beratung und Planung</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">4. Verpflichtungen des Auftraggebers</h2>
            <p className="mb-4">
              Der Auftraggeber verpflichtet sich:
            </p>
            <ul className="list-disc list-inside mb-4 space-y-2">
              <li>Alle erforderlichen Genehmigungen und behördlichen Zustimmungen rechtzeitig zu beschaffen</li>
              <li>Den Auftragnehmer über alle Umstände zu informieren, die für die Ausführung der Leistungen von Bedeutung sind</li>
              <li>Den Zugang zum Objekt zu gewährleisten</li>
              <li>Für die ordnungsgemäße Absicherung der Baustelle zu sorgen</li>
              <li>Die vereinbarten Zahlungen fristgerecht zu leisten</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">5. Preise und Zahlungsbedingungen</h2>
            <p className="mb-4">
              Alle Preise verstehen sich zuzüglich der gesetzlichen Mehrwertsteuer. Die Preise gelten für die in der Auftragsbestätigung beschriebenen Leistungen. Änderungen oder Ergänzungen des Leistungsumfangs können zu Preisänderungen führen.
            </p>
            <p className="mb-4">
              Rechnungen sind innerhalb von 14 Tagen nach Rechnungsstellung ohne Abzug zur Zahlung fällig. Bei Zahlungsverzug werden Verzugszinsen in Höhe von 9 Prozentpunkten über dem Basiszinssatz berechnet.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">6. Termine und Fristen</h2>
            <p className="mb-4">
              Termine und Fristen sind nur dann verbindlich, wenn sie schriftlich bestätigt wurden. Der Auftragnehmer ist berechtigt, die vereinbarten Termine zu überschreiten, wenn der Auftraggeber seine Mitwirkungspflichten nicht erfüllt oder durch höhere Gewalt behindert wird.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">7. Haftung</h2>
            <p className="mb-4">
              Der Auftragnehmer haftet unbeschränkt für Vorsatz und grobe Fahrlässigkeit. Bei leichter Fahrlässigkeit haftet der Auftragnehmer nur bei Verletzung einer wesentlichen Vertragspflicht (Kardinalpflicht). Die Haftung ist in diesem Fall auf den vorhersehbaren, vertragstypischen Schaden begrenzt.
            </p>
            <p className="mb-4">
              Die Haftung für leichte Fahrlässigkeit ist ausgeschlossen, soweit nicht Schäden aus der Verletzung des Lebens, des Körpers oder der Gesundheit oder aus der Verletzung wesentlicher Vertragspflichten resultieren.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">8. Gewährleistung</h2>
            <p className="mb-4">
              Die Gewährleistungsfrist beträgt ein Jahr ab Abnahme der Leistung. Der Auftraggeber hat Mängel unverzüglich schriftlich anzuzeigen. Die Gewährleistung erstreckt sich nur auf die Beseitigung von Mängeln. Weitere Ansprüche sind ausgeschlossen.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">9. Aufrechnung und Zurückbehaltung</h2>
            <p className="mb-4">
              Der Auftraggeber kann nur mit unbestrittenen oder rechtskräftig festgestellten Forderungen aufrechnen oder ein Zurückbehaltungsrecht geltend machen.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">10. Schlussbestimmungen</h2>
            <p className="mb-4">
              Es gilt deutsches Recht unter Ausschluss des UN-Kaufrechts. Gerichtsstand für alle Streitigkeiten aus diesem Vertragsverhältnis ist Köln, sofern der Auftraggeber Kaufmann, juristische Person des öffentlichen Rechts oder öffentlich-rechtliches Sondervermögen ist.
            </p>
            <p className="mb-4">
              Sollten einzelne Bestimmungen dieser AGB unwirksam sein oder werden, bleibt die Wirksamkeit der übrigen Bestimmungen unberührt.
            </p>
          </section>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10">
          <Link href="/" className="text-rose-400 hover:text-rose-500 transition-colors" aria-label="Zurück zur Startseite">
            &larr; Zurück zur Startseite
          </Link>
        </div>
      </div>
    </div>
  );
}




