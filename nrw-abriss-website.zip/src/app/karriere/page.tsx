import Link from "next/link";

export default function KarrierePage() {
  return (
    <div className="min-h-screen bg-[#030303] text-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-rose-400 via-white/90 to-white/70 bg-clip-text text-transparent">
          Karriere bei NRW Abriss
        </h1>
        
        <div className="space-y-8 text-white/80">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Werden Sie Teil unseres Teams!</h2>
            <p className="mb-4">
              Bei NRW Abriss suchen wir engagierte und motivierte Mitarbeiter, die Teil unseres erfahrenen Teams werden möchten. Wir bieten Ihnen interessante Aufgaben, ein kollegiales Arbeitsklima und vielfältige Entwicklungsmöglichkeiten.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Aktuelle Stellenangebote</h2>
            <p className="mb-4">
              Wir suchen aktuell nach folgenden Positionen:
            </p>
            
            <div className="space-y-6">
              <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-white mb-2">Abrissarbeiter (m/w/d)</h3>
                <p className="mb-4">Vollzeit, unbefristet</p>
                <p className="mb-4">
                  Wir suchen erfahrene Abrissarbeiter für unsere Abbrucharbeiten. Sie bringen Erfahrung im Umgang mit Baumaschinen mit und arbeiten gerne im Team.
                </p>
                <ul className="list-disc list-inside mb-4 space-y-2">
                  <li>Abgeschlossene Ausbildung im Baugewerbe</li>
                  <li>Erfahrung mit Baumaschinen</li>
                  <li>Teamfähigkeit und Zuverlässigkeit</li>
                  <li>Körperliche Belastbarkeit</li>
                </ul>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-white mb-2">Baufahrzeugführer (m/w/d)</h3>
                <p className="mb-4">Vollzeit, unbefristet</p>
                <p className="mb-4">
                  Für unsere Baustellen suchen wir erfahrene Baufahrzeugführer mit Führerschein CE.
                </p>
                <ul className="list-disc list-inside mb-4 space-y-2">
                  <li>Führerschein CE</li>
                  <li>Mehrjährige Berufserfahrung</li>
                  <li>Kenntnisse im Abbruchbereich von Vorteil</li>
                  <li>Zuverlässigkeit und Pünktlichkeit</li>
                </ul>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-white mb-2">Auszubildender (m/w/d)</h3>
                <p className="mb-4">Ausbildung zum Hochbaufacharbeiter</p>
                <p className="mb-4">
                  Wir bieten jungen Menschen die Möglichkeit, eine fundierte Ausbildung im Bereich Abbruch und Entsorgung zu absolvieren.
                </p>
                <ul className="list-disc list-inside mb-4 space-y-2">
                  <li>Guter Hauptschulabschluss oder höher</li>
                  <li>Interesse am Baugewerbe</li>
                  <li>Teamfähigkeit und Lernbereitschaft</li>
                  <li>Körperliche Belastbarkeit</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Was wir Ihnen bieten</h2>
            <ul className="list-disc list-inside mb-4 space-y-2">
              <li>Attraktive Vergütung</li>
              <li>Langfristige Beschäftigungsperspektiven</li>
              <li>Fortbildungsmöglichkeiten</li>
              <li>Kollegiales Arbeitsklima</li>
              <li>Moderne Arbeitsmittel und Maschinen</li>
              <li>Betriebliche Altersvorsorge</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Bewerbung</h2>
            <p className="mb-4">
              Haben wir Ihr Interesse geweckt? Dann freuen wir uns auf Ihre aussagekräftige Bewerbung mit Lebenslauf und Zeugnissen.
            </p>
            <p className="mb-4">
              Bitte senden Sie Ihre Bewerbung an:
            </p>
            <div className="bg-white/5 border border-white/10 rounded-lg p-6">
              <p className="mb-2"><strong>NRW Abriss GmbH</strong></p>
              <p className="mb-2">Personalabteilung</p>
              <p className="mb-2">Gotenring 18</p>
              <p className="mb-2">50679 Köln</p>
              <p className="mb-2">Deutschland</p>
              <p className="mb-2">Tel.: 0221/29491092</p>
              <p className="mb-2">E-Mail: info@nrw-abriss.de</p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Initiativbewerbung</h2>
            <p className="mb-4">
              Sie finden keine passende Stelle in unseren aktuellen Ausschreibungen? Dann bewerben Sie sich initiativ! Wir freuen uns über jede Bewerbung und prüfen, ob wir eine passende Position für Sie haben.
            </p>
          </section>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10">
          <Link href="/" className="text-rose-400 hover:text-rose-500 transition-colors" aria-label="Zurück zur Startseite">
            &larr; Zurück zur Startseite
          </Link>
        </div>
      </div>
    </div>
  );
}




