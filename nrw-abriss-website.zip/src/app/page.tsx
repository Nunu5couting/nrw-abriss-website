import { DemoHeroGeometric } from "@/components/ui/demo";
import { LogoCarouselDemo } from "@/components/ui/logo-carousel-demo-final";
import { ServicesWithImages } from "@/components/ui/services-with-images";
import { WhyUsSection } from "@/components/ui/why-us-section";
import { AboutSection } from "@/components/ui/about-section";
import { TestimonialsDemo } from "@/components/ui/testimonials-demo";
import { CTASection } from "@/components/ui/cta-section";
import { Footer } from "@/components/ui/footer-section";

export default function Home() {
  return (
    <div className="min-h-screen">
      <DemoHeroGeometric />
      <div id="clients">
        <LogoCarouselDemo />
      </div>
      <div id="services">
        <ServicesWithImages />
      </div>
      <div id="why-us">
        <WhyUsSection />
      </div>
      <div id="about">
        <AboutSection />
      </div>
      <div id="testimonials">
        <TestimonialsDemo />
      </div>
      <div id="contact">
        <CTASection />
      </div>
      <Footer />
    </div>
  );
}
