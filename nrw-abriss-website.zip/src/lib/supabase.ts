import { createClient } from '@supabase/supabase-js'

// Validate Supabase configuration
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

// Check if we have valid Supabase configuration
const hasValidConfig = supabaseUrl && 
  supabaseAnonKey && 
  supabaseUrl.startsWith('https://') && 
  supabaseUrl.includes('.supabase.co') &&
  supabaseAnonKey.length > 20

const isDevelopment = process.env.NODE_ENV === 'development'

if (isDevelopment && !hasValidConfig) {
  console.warn('⚠️  Supabase environment variables not found or invalid!')
  console.warn('Please create a .env.local file with:')
  console.warn('NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co')
  console.warn('NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key')
  console.warn('The app will run in demo mode without database functionality.')
}

// Use fallback values for demo mode
const finalSupabaseUrl = hasValidConfig ? supabaseUrl : 'https://demo.supabase.co'
const finalSupabaseAnonKey = hasValidConfig ? supabaseAnonKey : 'demo-key'

export const supabase = createClient(finalSupabaseUrl, finalSupabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
})

// Export a flag to check if Supabase is properly configured
export const isSupabaseConfigured = hasValidConfig

// Database types
export interface Contact {
  id: string
  name: string
  email: string
  phone?: string
  message: string
  project_type?: string
  created_at: string
  updated_at: string
}

export interface NewsletterSubscriber {
  id: string
  email: string
  subscribed_at: string
  is_active: boolean
  unsubscribed_at?: string
}

export interface Testimonial {
  id: string
  name: string
  role?: string
  company?: string
  content: string
  rating?: number
  is_featured: boolean
  created_at: string
  updated_at: string
}

export interface Project {
  id: string
  title: string
  description?: string
  image_url?: string
  project_type?: string
  location?: string
  completed_at?: string
  is_featured: boolean
  created_at: string
  updated_at: string
}

export interface Service {
  id: string
  title: string
  description: string
  icon?: string
  image_url?: string
  order_index: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface VisitorLog {
  id: string
  ip_address?: string
  user_agent?: string
  page_visited?: string
  referrer?: string
  created_at: string
}
