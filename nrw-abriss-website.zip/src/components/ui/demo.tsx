import { HeroWithImage } from "@/components/ui/hero-with-image"

function DemoHeroGeometric() {
    return <HeroWithImage 
        badge="NRW Abriss"
        title1="Herzlich willkommen"
        title2="Die Experten für Ihr Projekt"
        description="Mit uns steht Ihnen ein erfahrenes und spezialisiertes Team zur Seite, welches diese Verantwortung stets gewährleisten kann. Wir bieten Ihnen Lösungen aus einer Hand."
    />
}

export { DemoHeroGeometric }


