'use client';
import React from 'react';
import type { ComponentProps, ReactNode } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { FacebookIcon, MapPinIcon, PhoneIcon, MailIcon, InstagramIcon } from 'lucide-react';

interface FooterLink {
	title: string;
	href: string;
	icon?: React.ComponentType<{ className?: string }>;
}

interface FooterSection {
	label: string;
	links: FooterLink[];
}

const footerLinks: FooterSection[] = [
	{
		label: 'Leistungen',
		links: [
			{ title: 'Abrissarbeiten', href: '#services' },
			{ title: 'Innenraum-Abbruch', href: '#services' },
			{ title: 'Entkernung', href: '#services' },
			{ title: 'Schadstoffsanierung', href: '#services' },
			{ title: 'Umweltgerechte Entsorgung', href: '#services' },
			{ title: 'Recycling & Wiederverwertung', href: '#services' },
		],
	},
	{
		label: 'Unternehmen',
		links: [
			{ title: 'Über uns', href: '/#about' },
			{ title: 'Warum NRW Abriss', href: '/#why-us' },
			{ title: 'Unsere Kunden', href: '/#clients' },
			{ title: 'Kundenstimmen', href: '/#testimonials' },
			{ title: 'Karriere', href: '/karriere' },
			{ title: 'Kontakt', href: '/#contact' },
		],
	},
	{
		label: 'Rechtliches',
		links: [
			{ title: 'Impressum', href: '/impressum' },
			{ title: 'Datenschutzerklärung', href: '/datenschutz' },
			{ title: 'AGB', href: '/agb' },
			{ title: 'Widerrufsrecht', href: '/widerruf' },
			{ title: 'Cookie-Richtlinie', href: '/cookies' },
		],
	},
	{
		label: 'Kontakt',
		links: [
			{ title: 'Gotenring 18, 50679 Köln', href: 'https://maps.google.com/?q=Gotenring+18,+50679+Köln', icon: MapPinIcon },
			{ title: 'Tel: 0221/29491092', href: 'tel:022129491092', icon: PhoneIcon },
			{ title: 'info@nrw-abriss.de', href: 'mailto:info@nrw-abriss.de', icon: MailIcon },
			{ title: 'Fax: 0221/29491092', href: 'tel:022129491092' },
			{ title: 'Mobil: +49 1722887227', href: 'tel:+491722887227' },
		],
	},
];

export function Footer() {
	return (
		<footer className="relative w-full bg-[#030303] border-t border-white/[0.08] px-6 py-12 lg:py-16 overflow-hidden">
			{/* Background Effects */}
            <div className="absolute inset-0 bg-gradient-to-t from-rose-500/[0.02] via-transparent to-black/[0.02]" />
			
			{/* Enhanced Ambient Line Network */}
			<motion.div
				className="absolute inset-0 pointer-events-none"
				initial={{ opacity: 0 }}
				animate={{ opacity: 0.15 }}
				transition={{ duration: 4 }}
			>
				{/* Vertical Lines */}
				{[...Array(10)].map((_, i) => (
					<motion.div
						key={`v-${i}`}
						className="absolute w-px h-full bg-gradient-to-b from-transparent via-rose-500/25 to-transparent"
						style={{
							left: `${(i + 1) * 10}%`,
						}}
						animate={{
							scaleY: [0, 1, 0],
							opacity: [0, 0.4, 0],
						}}
						transition={{
							duration: 12,
							repeat: Infinity,
							ease: "easeInOut",
							delay: i * 1.2,
						}}
					/>
				))}
				
				{/* Horizontal Lines */}
				{[...Array(8)].map((_, i) => (
					<motion.div
						key={`h-${i}`}
						className="absolute w-full h-px bg-gradient-to-r from-transparent via-rose-500/25 to-transparent"
						style={{
							top: `${(i + 1) * 12.5}%`,
						}}
						animate={{
							scaleX: [0, 1, 0],
							opacity: [0, 0.4, 0],
						}}
						transition={{
							duration: 15,
							repeat: Infinity,
							ease: "easeInOut",
							delay: i * 1.8,
						}}
					/>
				))}
				
				{/* Diagonal Lines */}
				{[...Array(6)].map((_, i) => (
					<motion.div
						key={`d-${i}`}
						className="absolute w-px h-full bg-gradient-to-b from-transparent via-rose-500/15 to-transparent"
						style={{
							left: `${(i + 1) * 16.67}%`,
							transform: `rotate(${45 + i * 15}deg)`,
							transformOrigin: "top",
						}}
						animate={{
							scaleY: [0, 1, 0],
							opacity: [0, 0.3, 0],
						}}
						transition={{
							duration: 18,
							repeat: Infinity,
							ease: "easeInOut",
							delay: i * 2.5,
						}}
					/>
				))}
			</motion.div>
			
			{/* Decorative Line */}
            <div className="bg-gradient-to-r from-rose-500/20 via-rose-500 to-rose-500/20 absolute top-0 right-1/2 left-1/2 h-px w-1/3 -translate-x-1/2 -translate-y-1/2 rounded-full blur" />

			<div className="max-w-6xl mx-auto">
				<div className="grid w-full gap-8 xl:grid-cols-3 xl:gap-8">
					<AnimatedContainer className="space-y-4">
						<div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-r from-rose-500 to-black rounded-xl flex items-center justify-center">
								<span className="text-white font-bold text-lg">NRW</span>
							</div>
							<div>
								<h2 className="text-2xl font-bold text-white">NRW Abriss</h2>
                                <p className="text-rose-400 text-sm">Professioneller Abbruch & Entsorgung</p>
							</div>
						</div>
						<p className="text-white/60 mt-8 text-sm md:mt-4 max-w-sm">
							Ihr erfahrener Partner für professionelle Abbrucharbeiten. 
							Von der Beratung bis zur Entsorgung - wir bieten Lösungen aus einer Hand.
						</p>
					</AnimatedContainer>

					<div className="mt-10 grid grid-cols-2 gap-8 md:grid-cols-4 xl:col-span-2 xl:mt-0">
						{footerLinks.map((section, index) => (
							<AnimatedContainer key={section.label} delay={0.1 + index * 0.1}>
								<div className="mb-10 md:mb-0">
									<h3 className="text-white font-semibold text-sm mb-4">{section.label}</h3>
									<ul className="text-white/60 space-y-3 text-sm">
										{section.links.map((link) => (
											<li key={link.title}>
												<a
													href={link.href}
                                                    className="hover:text-rose-400 inline-flex items-center transition-all duration-300 group"
												>
                                                    {link.icon && <link.icon className="me-2 size-4 group-hover:text-rose-400 transition-colors" />}
													<span className="group-hover:translate-x-1 transition-transform">{link.title}</span>
												</a>
											</li>
										))}
									</ul>
								</div>
							</AnimatedContainer>
						))}
					</div>
				</div>

				{/* Bottom Section */}
				<AnimatedContainer delay={0.5} className="mt-12 pt-8 border-t border-white/[0.08]">
					<div className="flex flex-col md:flex-row justify-between items-center gap-4">
						<p className="text-white/60 text-sm">
							© {new Date().getFullYear()} NRW Abriss GmbH. Alle Rechte vorbehalten.
						</p>
						<div className="flex items-center gap-6 flex-wrap justify-center md:justify-end">
							<a href="/impressum" className="text-white/60 hover:text-rose-400 transition-colors text-sm">
								Impressum
							</a>
							<a href="/datenschutz" className="text-white/60 hover:text-rose-400 transition-colors text-sm">
								Datenschutz
							</a>
							<a href="/agb" className="text-white/60 hover:text-rose-400 transition-colors text-sm">
								AGB
							</a>
							<a href="/widerruf" className="text-white/60 hover:text-rose-400 transition-colors text-sm">
								Widerruf
							</a>
							<a href="/cookies" className="text-white/60 hover:text-rose-400 transition-colors text-sm">
								Cookies
							</a>
						</div>
					</div>
				</AnimatedContainer>
			</div>
		</footer>
	);
}

type ViewAnimationProps = {
	delay?: number;
	className?: ComponentProps<typeof motion.div>['className'];
	children: ReactNode;
};

function AnimatedContainer({ className, delay = 0.1, children }: ViewAnimationProps) {
	const shouldReduceMotion = useReducedMotion();

	if (shouldReduceMotion) {
		return children;
	}

	return (
		<motion.div
			initial={{ filter: 'blur(4px)', translateY: -8, opacity: 0 }}
			whileInView={{ filter: 'blur(0px)', translateY: 0, opacity: 1 }}
			viewport={{ once: true }}
			transition={{ delay, duration: 0.8 }}
			className={className}
		>
			{children}
		</motion.div>
	);
}
