import { TestimonialsSectionWithScroll } from "@/components/ui/testimonials-with-scroll"

const testimonials = [
  {
    author: {
      name: "Thomas Müller",
      handle: "Ford Köln",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
    },
    text: "NRW Abriss hat unseren kompletten Produktionsstandort professionell abgerissen. Die Termine wurden eingehalten und die Entsorgung war umweltgerecht.",
  },
  {
    author: {
      name: "Sarah Weber",
      handle: "Fröbel Kindergarten",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face"
    },
    text: "Besonders beeindruckend war die Sorgfalt bei den Innenraum-Abbrucharbeiten in unserem Kindergarten. Alles wurde kindersicher durchgeführt.",
  },
  {
    author: {
      name: "Dr. Michael Schmidt",
      handle: "DLR Köln",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
    },
    text: "Die moderne Technik und Präzision bei unseren Forschungsanlagen war außergewöhnlich. Sehr zu empfehlen für komplexe Abbrucharbeiten.",
  },
  {
    author: {
      name: "Lisa Hoffmann",
      handle: "Jumo Solingen",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face"
    },
    text: "Effiziente Abläufe und erstklassiger Service. Unser Neubau konnte pünktlich beginnen, da die Abbrucharbeiten termingerecht abgeschlossen wurden.",
  },
  {
    author: {
      name: "Marco Rossi",
      handle: "Loco Chicken",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face"
    },
    text: "Die umweltgerechte Entsorgung war für uns sehr wichtig. NRW Abriss hat alle Materialien fachgerecht recycelt und entsorgt.",
  },
  {
    author: {
      name: "Anna Friedrich",
      handle: "Friedrich Wassermann",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
    },
    text: "Von der Beratung bis zur Entsorgung - ein Rundum-Service. Das Team war immer erreichbar und hat alle Fragen kompetent beantwortet.",
  }
]

export function TestimonialsDemo() {
  return (
    <TestimonialsSectionWithScroll
      title="Was unsere Kunden sagen"
      description="Überzeugen Sie sich selbst von der Qualität unserer Arbeit durch die Erfahrungen unserer zufriedenen Kunden"
      testimonials={testimonials}
    />
  )
}
