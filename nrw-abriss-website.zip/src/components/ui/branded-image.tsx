"use client";

import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";
import React, { useRef } from "react";

type TextSide = "left" | "right";
type Focal = "left" | "center" | "right";

interface BrandedImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  /** Which side will host text overlay; we darken that side for readability */
  textSide?: TextSide;
  /** Asymmetrical crop: object position focus */
  focal?: Focal;
  /** Coral overlay strength 0..1 */
  coralOpacity?: number;
  /** Enable subtle parallax on scroll */
  parallax?: boolean;
}

export function BrandedImage({
  src,
  alt,
  width = 1600,
  height = 900,
  className,
  textSide = "left",
  focal = "left",
  coralOpacity = 0.25,
  parallax = true,
}: BrandedImageProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ["start end", "end start"] });
  const translateY = useTransform(scrollYProgress, [0, 1], [0, parallax ? -20 : 0]);

  const objectPosition = focal === "left" ? "object-[15%_center]" : focal === "right" ? "object-[85%_center]" : "object-center";
  const vignetteClass = textSide === "left" ? "bg-gradient-to-r from-black/55 via-black/25 to-transparent" : "bg-gradient-to-l from-black/55 via-black/25 to-transparent";

  const coralBg = `bg-[rgba(255,64,64,${coralOpacity})]` as const;

  return (
    <motion.div ref={containerRef} style={{ y: translateY }} className={`relative overflow-hidden rounded-2xl group ${className ?? ""}`}>
      <Image
        src={src}
        alt={alt}
        width={width}
        height={height}
        className={`h-[256px] w-full object-cover group-hover:scale-105 transition-transform duration-700 ${objectPosition}`}
        priority={false}
      />

      {/* Enhanced Coral duotone overlay for brand cohesion */}
      <div className={`absolute inset-0 mix-blend-soft-light ${coralBg}`} />
      <div className="absolute inset-0 bg-gradient-to-br from-rose-500/10 via-transparent to-amber-500/5" />
      
      {/* Enhanced readability vignette towards text side */}
      <div className={`absolute inset-0 ${vignetteClass}`} />
      
      {/* Enhanced grain for cinematic feel */}
      <motion.div 
        className="pointer-events-none absolute inset-0 opacity-[0.12] [background-image:radial-gradient(rgba(255,255,255,0.22)_1px,transparent_1px)] [background-size:3px_3px]"
        animate={{ 
          opacity: [0.12, 0.18, 0.12],
        }}
        transition={{ 
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Subtle light reflection */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/8 via-transparent to-transparent" />

      {/* Fade-in on enter */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true, amount: 0.4 }}
        className="absolute inset-0"
      />
    </motion.div>
  );
}

export default BrandedImage;


