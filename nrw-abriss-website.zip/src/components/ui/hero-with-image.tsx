"use client";

import { motion, useMotionValue, useTransform, animate, useScroll, useSpring } from "framer-motion";
import Image from "next/image";
import { Circle } from "lucide-react";
import { useEffect, useState, useRef } from "react";
import { cn } from "@/lib/utils";

function ElegantShape({
    className,
    delay = 0,
    width = 400,
    height = 100,
    rotate = 0,
    gradient = "from-white/[0.08]",
}: {
    className?: string;
    delay?: number;
    width?: number;
    height?: number;
    rotate?: number;
    gradient?: string;
}) {
    return (
        <motion.div
            initial={{
                opacity: 0,
                y: -150,
                rotate: rotate - 15,
            }}
            animate={{
                opacity: 1,
                y: 0,
                rotate: rotate,
            }}
            transition={{
                duration: 2.4,
                delay,
                ease: [0.23, 0.86, 0.39, 0.96],
                opacity: { duration: 1.2 },
            }}
            className={cn("absolute", className)}
        >
            <motion.div
                animate={{
                    y: [0, 15, 0],
                }}
                transition={{
                    duration: 12,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                }}
                style={{
                    width,
                    height,
                }}
                className="relative"
            >
                <div
                    className={cn(
                        "absolute inset-0 rounded-full",
                        "bg-gradient-to-r to-transparent",
                        gradient,
                        "backdrop-blur-[2px] border-2 border-white/[0.15]",
                        "shadow-[0_8px_32px_0_rgba(255,255,255,0.1)]",
                        "after:absolute after:inset-0 after:rounded-full",
                        "after:bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.2),transparent_70%)]"
                    )}
                />
            </motion.div>
        </motion.div>
    );
}

function HeroWithImage({
    badge = "NRW Abriss",
    title1 = "Herzlich willkommen",
    title2 = "Die Experten für Ihr Projekt",
    description = "Abriss bedeutet Verantwortung. Mit uns steht Ihnen ein erfahrenes und spezialisiertes Team zur Seite, welches diese Verantwortung stets gewährleisten kann. Wir bieten Ihnen Lösungen aus einer Hand.",
    heroImageSrc = "/images/hero-construction.svg",
}: {
    badge?: string;
    title1?: string;
    title2?: string;
    description?: string;
    heroImageSrc?: string;
}) {
    const containerRef = useRef<HTMLDivElement>(null);
    const { scrollYProgress } = useScroll({
        target: containerRef,
        offset: ["start start", "end start"]
    });

    // Parallax transforms
    const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
    const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [1, 0.8, 0]);
    const scale = useTransform(scrollYProgress, [0, 1], [1, 1.05]);
    const fadeUpVariants = {
        hidden: { opacity: 0, y: 60, scale: 0.95 },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                duration: 1.2,
                delay: 0.3,
                ease: [0.25, 0.46, 0.45, 0.94], // Ease-In-Out-Cubic
            },
        },
    } as const;

    const staggerContainer = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.15,
                delayChildren: 0.2,
            },
        },
    };

    const ambientFloat = {
        animate: {
            y: [0, -20, 0],
            rotate: [0, 2, 0],
        },
        transition: {
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut" as const,
        },
    };

    return (
        <div ref={containerRef} className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#030303]">
            {/* 3D Background Layers */}
            <div className="absolute inset-0">
                {/* Layer 1: Deep Background */}
                <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-gray-900 via-gray-800 to-black"
                    style={{ 
                        scale: useTransform(scrollYProgress, [0, 1], [1, 1.1]),
                        opacity: useTransform(scrollYProgress, [0, 0.5, 1], [1, 0.8, 0.6])
                    }}
                />
                
                {/* Layer 2: Background Image with Enhanced Parallax */}
                {heroImageSrc ? (
                    <motion.div
                        className="absolute inset-0"
                    >
                        <Image
                            src={heroImageSrc}
                            alt="Baustelle Hintergrund"
                            fill
                            priority
                            className="object-cover opacity-40"
                        />
                    </motion.div>
                ) : null}
                
                {/* Layer 3: Dynamic Light Rays */}
                <motion.div
                    className="absolute inset-0"
                    animate={{
                        background: [
                            "radial-gradient(circle at 30% 20%, rgba(251,113,133,0.3) 0%, transparent 60%)",
                            "radial-gradient(circle at 70% 80%, rgba(251,146,60,0.2) 0%, transparent 50%)",
                            "radial-gradient(circle at 30% 20%, rgba(251,113,133,0.3) 0%, transparent 60%)"
                        ]
                    }}
                    transition={{
                        duration: 8,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                />
                
                {/* Layer 4: Particle System */}
                <motion.div
                    className="absolute inset-0 pointer-events-none"
                    style={{ 
                        opacity: useTransform(scrollYProgress, [0, 0.5, 1], [0.6, 0.3, 0])
                    }}
                >
                    {[...Array(30)].map((_, i) => (
                        <motion.div
                            key={i}
                            className="absolute w-1 h-1 bg-rose-500/30 rounded-full"
                            style={{
                                left: `${Math.random() * 100}%`,
                                top: `${Math.random() * 100}%`,
                            }}
                            animate={{
                                y: [0, -200, 0],
                                x: [0, Math.random() * 100 - 50, 0],
                                opacity: [0, 1, 0],
                                scale: [0, 1, 0],
                            }}
                            transition={{
                                duration: 4 + Math.random() * 3,
                                repeat: Infinity,
                                delay: Math.random() * 2,
                                ease: "easeInOut",
                            }}
                        />
                    ))}
                </motion.div>
            </div>

            <div className="absolute inset-0 overflow-hidden">
                <motion.div
                    animate={ambientFloat.animate}
                    transition={ambientFloat.transition}
                    className="absolute left-[-10%] md:left-[-5%] top-[15%] md:top-[20%]"
                >
                    <ElegantShape
                        delay={0.3}
                        width={600}
                        height={140}
                        rotate={12}
                        gradient="from-rose-500/[0.2]"
                    />
                </motion.div>

                <motion.div
                    animate={ambientFloat.animate}
                    transition={{ ...ambientFloat.transition, delay: 2 }}
                    className="absolute right-[-5%] md:right-[0%] top-[70%] md:top-[75%]"
                >
                    <ElegantShape
                        delay={0.5}
                        width={500}
                        height={120}
                        rotate={-15}
                        gradient="from-black/[0.2]"
                    />
                </motion.div>

                <motion.div
                    animate={ambientFloat.animate}
                    transition={{ ...ambientFloat.transition, delay: 4 }}
                    className="absolute left-[5%] md:left-[10%] bottom-[5%] md:bottom-[10%]"
                >
                    <ElegantShape
                        delay={0.4}
                        width={300}
                        height={80}
                        rotate={-8}
                        gradient="from-amber-600/[0.2]"
                    />
                </motion.div>

                <motion.div
                    animate={ambientFloat.animate}
                    transition={{ ...ambientFloat.transition, delay: 6 }}
                    className="absolute right-[15%] md:right-[20%] top-[10%] md:top-[15%]"
                >
                    <ElegantShape
                        delay={0.6}
                        width={200}
                        height={60}
                        rotate={20}
                        gradient="from-rose-500/[0.2]"
                    />
                </motion.div>

                <motion.div
                    animate={ambientFloat.animate}
                    transition={{ ...ambientFloat.transition, delay: 1 }}
                    className="absolute left-[20%] md:left-[25%] top-[5%] md:top-[10%]"
                >
                    <ElegantShape
                        delay={0.7}
                        width={150}
                        height={40}
                        rotate={-25}
                        gradient="from-black/[0.2]"
                    />
                </motion.div>
            </div>

            <motion.div 
                className="relative z-20 container mx-auto px-4 md:px-6"
                style={{ 
                    opacity: useTransform(scrollYProgress, [0, 0.5, 1], [1, 0.9, 0.7]),
                    y: useTransform(scrollYProgress, [0, 1], ["0%", "-10%"])
                }}
            >
                <motion.div 
                    className="max-w-5xl mx-auto text-center"
                    variants={staggerContainer}
                    initial="hidden"
                    animate="visible"
                >
                    <motion.div
                        custom={0}
                        variants={fadeUpVariants}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/[0.05] border border-white/[0.12] mb-8 md:mb-12 backdrop-blur-sm"
                    >
                        <motion.div
                            animate={{ 
                                scale: [1, 1.2, 1],
                                opacity: [0.8, 1, 0.8]
                            }}
                            transition={{ 
                                duration: 2,
                                repeat: Infinity,
                                ease: "easeInOut"
                            }}
                        >
                            <Circle className="h-2 w-2 fill-rose-500/80" />
                        </motion.div>
                        <span className="text-sm text-white/70 tracking-wide font-medium">
                            {badge}
                        </span>
                    </motion.div>

                    <motion.div
                        custom={1}
                        variants={fadeUpVariants}
                    >
                        <h1 className="text-4xl sm:text-6xl md:text-8xl font-bold mb-6 md:mb-8 tracking-tight">
                            <motion.span 
                                className="bg-clip-text text-transparent bg-gradient-to-b from-white to-white/80"
                                animate={{
                                    backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"]
                                }}
                                transition={{
                                    duration: 8,
                                    repeat: Infinity,
                                    ease: "easeInOut"
                                }}
                            >
                                {title1}
                            </motion.span>
                            <br />
                            <motion.span
                                className="bg-clip-text text-transparent bg-gradient-to-r from-rose-400 via-white/90 to-white/70"
                                animate={{
                                    backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"]
                                }}
                                transition={{
                                    duration: 6,
                                    repeat: Infinity,
                                    ease: "easeInOut",
                                    delay: 1
                                }}
                            >
                                {title2}
                            </motion.span>
                        </h1>
                    </motion.div>

                    <motion.div
                        custom={2}
                        variants={fadeUpVariants}
                    >
                        <p className="text-lg sm:text-xl md:text-2xl text-white/70 mb-8 leading-relaxed font-light tracking-wide max-w-3xl mx-auto px-4">
                            {description}
                        </p>
                    </motion.div>

                    <motion.div
                        custom={3}
                        variants={fadeUpVariants}
                        className="flex flex-col sm:flex-row gap-4 justify-center items-center"
                    >
                        <motion.button 
                            className="px-10 py-5 bg-gradient-to-r from-rose-500 via-rose-600 to-rose-700 text-white font-bold text-lg rounded-xl transition-all duration-300 shadow-2xl backdrop-blur-sm"
                            whileHover={{ 
                                scale: 1.05,
                                boxShadow: "0 20px 40px rgba(251, 113, 133, 0.4)"
                            }}
                            whileTap={{ scale: 0.98 }}
                            animate={{
                                boxShadow: [
                                    "0 10px 30px rgba(251, 113, 133, 0.2)",
                                    "0 15px 35px rgba(251, 113, 133, 0.3)",
                                    "0 10px 30px rgba(251, 113, 133, 0.2)"
                                ]
                            }}
                            transition={{
                                duration: 3,
                                repeat: Infinity,
                                ease: "easeInOut"
                            }}
                        >
                            Kontakt aufnehmen
                        </motion.button>
                        <motion.button 
                            className="px-10 py-5 border-2 border-white/30 text-white font-bold text-lg rounded-xl backdrop-blur-sm"
                            whileHover={{ 
                                scale: 1.05,
                                backgroundColor: "rgba(255, 255, 255, 0.1)",
                                borderColor: "rgba(255, 255, 255, 0.5)"
                            }}
                            whileTap={{ scale: 0.98 }}
                        >
                            Portfolio ansehen
                        </motion.button>
                    </motion.div>
                </motion.div>
            </motion.div>

            <div className="absolute inset-0 bg-gradient-to-t from-[#030303] via-transparent to-[#030303]/80 pointer-events-none" />
        </div>
    );
}

export { HeroWithImage }
