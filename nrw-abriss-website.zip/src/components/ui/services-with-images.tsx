"use client";

import { motion, useScroll, useTransform } from "framer-motion";
// import Image from "next/image";
import BrandedImage from "@/components/ui/branded-image";
import { Shield, Recycle, Users, CheckCircle } from "lucide-react";
import { useRef } from "react";

function ElegantShape({
    className,
    delay = 0,
    width = 400,
    height = 100,
    rotate = 0,
    gradient = "from-white/[0.08]",
}: {
    className?: string;
    delay?: number;
    width?: number;
    height?: number;
    rotate?: number;
    gradient?: string;
}) {
    return (
        <motion.div
            initial={{
                opacity: 0,
                y: -150,
                rotate: rotate - 15,
            }}
            animate={{
                opacity: 1,
                y: 0,
                rotate: rotate,
            }}
            transition={{
                duration: 2.4,
                delay,
                ease: [0.23, 0.86, 0.39, 0.96],
                opacity: { duration: 1.2 },
            }}
            className={`absolute ${className}`}
        >
            <motion.div
                animate={{
                    y: [0, 15, 0],
                }}
                transition={{
                    duration: 12,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                }}
                style={{
                    width,
                    height,
                }}
                className="relative"
            >
                <div
                    className={`absolute inset-0 rounded-full bg-gradient-to-r to-transparent ${gradient} backdrop-blur-[2px] border-2 border-white/[0.15] shadow-[0_8px_32px_0_rgba(255,255,255,0.1)] after:absolute after:inset-0 after:rounded-full after:bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.2),transparent_70%)]`}
                />
            </motion.div>
        </motion.div>
    );
}

const services = [
    {
        icon: Shield,
        title: "MODERNE TECHNIK",
        description: "Unser spezialisiertes Team wird regelmäßig geschult. So garantieren wir einen sicheren Abbruch. Durch verschiedene Techniken stellen wir sicher, dass benachbarte Objekte und Personen nicht von Staub, Schmutz und Lärm betroffen werden.",
		gradient: "from-rose-500 to-black",
		imageSrc: "https://images.pexels.com/photos/3862371/pexels-photo-3862371.jpeg", // Hochwertiges Schweißen mit Funkenflug
    },
    {
        icon: Users,
        title: "INNENRAUM-ABBRUCH",
        description: "Spezialisierte Innenraum-Abbrucharbeiten mit höchster Präzision und Sorgfalt für Ihr Projekt. Wir garantieren saubere und effiziente Arbeiten.",
		gradient: "from-rose-400 to-rose-600",
		imageSrc: "https://images.pexels.com/photos/416405/pexels-photo-416405.jpeg", // Innenraum-Abbruch mit Bagger
    },
    {
        icon: CheckCircle,
        title: "EFFEKTIVE ABLÄUFE",
        description: "Routinierte Abläufe und erstklassiger Service für termingerechte und budgetgerechte Umsetzung Ihrer Abbrucharbeiten.",
		gradient: "from-amber-600 to-black",
		imageSrc: "https://images.pexels.com/photos/6474477/pexels-photo-6474477.jpeg", // Baustelle mit Planung
    },
    {
        icon: Recycle,
        title: "SORGFÄLTIGE ENTSORGUNG",
        description: "Ziel unserer Abfallwirtschaft ist es die Umwelt möglichst wenig zu beeinträchtigen und gleichzeitig den höchsten Nutzen aus den Abfällen zu ziehen. Das heißt wertvolle Rohstoffe zu erhalten und wiederzuverwerten.",
		gradient: "from-rose-500 to-rose-700",
		imageSrc: "https://images.pexels.com/photos/2804731/pexels-photo-2804731.jpeg", // Recycling und Entsorgung
    }
];

export function ServicesWithImages() {
    const containerRef = useRef<HTMLDivElement>(null);
    const { scrollYProgress } = useScroll({
        target: containerRef,
        offset: ["start end", "end start"]
    });

    // Parallax transforms
    const y = useTransform(scrollYProgress, [0, 1], ["0%", "-20%"]);
    const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [0, 1, 0]);
    const scale = useTransform(scrollYProgress, [0, 1], [0.8, 1]);

    const fadeUpVariants = {
        hidden: { opacity: 0, y: 60, scale: 0.9 },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                duration: 1.2,
                delay: 0.3,
                ease: [0.25, 0.46, 0.45, 0.94], // Ease-In-Out-Cubic
            },
        },
    } as const;

    const staggerContainer = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.2,
                delayChildren: 0.1,
            },
        },
    };

    const cardHover = {
        hover: {
            scale: 1.02,
            y: -10,
        },
        transition: {
            duration: 0.4,
            ease: [0.25, 0.46, 0.45, 0.94] as const,
        },
    };

    return (
        <div ref={containerRef} className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#030303]">
            <div className="absolute inset-0 bg-gradient-to-br from-rose-500/[0.05] via-transparent to-black/[0.05] blur-3xl" />
            
            {/* Enhanced Light Rays System */}
            <motion.div
                className="absolute inset-0 pointer-events-none"
                style={{ opacity: useTransform(scrollYProgress, [0, 0.5, 1], [0, 0.4, 0]) }}
            >
                {/* Light Rays */}
                {[...Array(8)].map((_, i) => (
                    <motion.div
                        key={`ray-${i}`}
                        className="absolute w-px h-full bg-gradient-to-b from-transparent via-rose-500/30 to-transparent"
                        style={{
                            left: `${(i + 1) * 12.5}%`,
                            transformOrigin: "top",
                        }}
                        animate={{
                            scaleY: [0, 1, 0],
                            opacity: [0, 0.6, 0],
                        }}
                        transition={{
                            duration: 4 + Math.random() * 2,
                            repeat: Infinity,
                            delay: i * 0.5,
                            ease: "easeInOut",
                        }}
                    />
                ))}
                
                {/* Dust Particles */}
                {[...Array(25)].map((_, i) => (
                    <motion.div
                        key={`particle-${i}`}
                        className="absolute w-1 h-1 bg-rose-500/30 rounded-full"
                        style={{
                            left: `${Math.random() * 100}%`,
                            top: `${Math.random() * 100}%`,
                        }}
                        animate={{
                            y: [0, -150, 0],
                            x: [0, Math.random() * 60 - 30, 0],
                            opacity: [0, 1, 0],
                            scale: [0, 1, 0],
                        }}
                        transition={{
                            duration: 4 + Math.random() * 3,
                            repeat: Infinity,
                            delay: Math.random() * 2,
                            ease: "easeInOut",
                        }}
                    />
                ))}
            </motion.div>

            <div className="absolute inset-0 overflow-hidden">
                <ElegantShape
                    delay={0.3}
                    width={600}
                    height={140}
                    rotate={12}
                    gradient="from-rose-500/[0.15]"
                    className="left-[-10%] md:left-[-5%] top-[15%] md:top-[20%]"
                />

                <ElegantShape
                    delay={0.5}
                    width={500}
                    height={120}
                    rotate={-15}
                    gradient="from-black/[0.15]"
                    className="right-[-5%] md:right-[0%] top-[70%] md:top-[75%]"
                />

                <ElegantShape
                    delay={0.4}
                    width={300}
                    height={80}
                    rotate={-8}
                    gradient="from-amber-600/[0.15]"
                    className="left-[5%] md:left-[10%] bottom-[5%] md:bottom-[10%]"
                />

                <ElegantShape
                    delay={0.6}
                    width={200}
                    height={60}
                    rotate={20}
                    gradient="from-rose-500/[0.15]"
                    className="right-[15%] md:right-[20%] top-[10%] md:top-[15%]"
                />
            </div>

            <motion.div 
                className="relative z-10 container mx-auto px-4 md:px-6"
                style={{ y, opacity, scale }}
            >
                <div className="max-w-7xl mx-auto">
                    <motion.div
                        custom={0}
                        variants={fadeUpVariants}
                        initial="hidden"
                        animate="visible"
                        className="text-center mb-16"
                    >
                        <h2 className="text-4xl sm:text-6xl md:text-7xl font-bold mb-6 md:mb-8 tracking-tight">
                            <span className="bg-clip-text text-transparent bg-gradient-to-r from-rose-400 via-white/90 to-white/70">
                                Was wir für Sie tun
                            </span>
                        </h2>
                        <p className="text-lg sm:text-xl md:text-2xl text-white/70 mb-8 leading-relaxed font-light tracking-wide max-w-3xl mx-auto">
                            Von der Beratung über die Planung und Einholung der Genehmigungen, bis hin zur fach- und umweltgerechten Entsorgung, sichern wir Ihnen eine gut organisierte und reibungslose Durchführung der Abbrucharbeiten.
                        </p>
                    </motion.div>

                    <motion.div 
                        className="grid grid-cols-1 lg:grid-cols-2 gap-12"
                        variants={staggerContainer}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true, amount: 0.3 }}
                    >
                        {services.map((service, index) => {
                            const IconComponent = service.icon;
                            return (
                                <motion.div
                                    key={service.title}
                                    custom={index + 1}
                                    variants={fadeUpVariants}
                                    className="group"
                                                whileHover={cardHover.hover}
                                                transition={cardHover.transition}
                                >
                                    <motion.div 
                                        className="bg-white/[0.05] border border-white/[0.12] rounded-3xl overflow-hidden backdrop-blur-sm relative"
                                        whileHover={{
                                            backgroundColor: "rgba(255, 255, 255, 0.08)",
                                            borderColor: "rgba(251, 113, 133, 0.3)",
                                            transition: { duration: 0.3 }
                                        }}
                                    >
                                        <div className="relative h-80">
                                            {service.imageSrc ? (
                                                <BrandedImage
                                                    src={service.imageSrc}
                                                    alt={service.title}
                                                    className="h-80"
                                                    textSide="left"
                                                    focal={index % 2 === 0 ? "left" : "right"}
                                                    coralOpacity={0.3}
                                                    parallax
                                                />
                                            ) : null}
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                                            
                                            {/* Ambient Light Effect */}
                                            <motion.div
                                                className="absolute inset-0 bg-gradient-to-br from-rose-500/10 via-transparent to-amber-500/5"
                                                animate={{
                                                    opacity: [0.3, 0.6, 0.3],
                                                }}
                                                transition={{
                                                    duration: 4,
                                                    repeat: Infinity,
                                                    ease: "easeInOut",
                                                    delay: index * 0.5
                                                }}
                                            />
                                            
                                            <div className="absolute bottom-6 left-6 right-6">
                                                <div className="flex items-center gap-4 mb-4">
                                                    <motion.div 
                                                        className="w-16 h-16 bg-gradient-to-r from-rose-500 via-rose-600 to-rose-700 rounded-2xl flex items-center justify-center shadow-2xl"
                                                        whileHover={{ 
                                                            scale: 1.15,
                                                            rotate: 5,
                                                            boxShadow: "0 20px 40px rgba(251, 113, 133, 0.4)"
                                                        }}
                                                        transition={{ duration: 0.3 }}
                                                    >
                                                        <IconComponent className="w-8 h-8 text-white" />
                                                    </motion.div>
                                                    <motion.h3 
                                                        className="text-3xl font-bold text-white"
                                                        whileHover={{ 
                                                            color: "#fecaca",
                                                            x: 5
                                                        }}
                                                        transition={{ duration: 0.3 }}
                                                    >
                                                        {service.title}
                                                    </motion.h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="p-8">
                                            <motion.p 
                                                className="text-white/70 leading-relaxed text-lg"
                                                initial={{ opacity: 0.7 }}
                                                whileHover={{ opacity: 1 }}
                                                transition={{ duration: 0.3 }}
                                            >
                                                {service.description}
                                            </motion.p>
                                        </div>
                                    </motion.div>
                                </motion.div>
                            );
                        })}
                    </motion.div>
                </div>
            </motion.div>

            <div className="absolute inset-0 bg-gradient-to-t from-[#030303] via-transparent to-[#030303]/80 pointer-events-none" />
        </div>
    );
}
