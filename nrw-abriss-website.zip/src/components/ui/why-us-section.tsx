"use client";

import { motion } from "framer-motion";
import { Circle, Headphones, Clock, Star, Award } from "lucide-react";

function ElegantShape({
    className,
    delay = 0,
    width = 400,
    height = 100,
    rotate = 0,
    gradient = "from-white/[0.08]",
}: {
    className?: string;
    delay?: number;
    width?: number;
    height?: number;
    rotate?: number;
    gradient?: string;
}) {
    return (
        <motion.div
            initial={{
                opacity: 0,
                y: -150,
                rotate: rotate - 15,
            }}
            animate={{
                opacity: 1,
                y: 0,
                rotate: rotate,
            }}
            transition={{
                duration: 2.4,
                delay,
                ease: [0.23, 0.86, 0.39, 0.96],
                opacity: { duration: 1.2 },
            }}
            className={`absolute ${className}`}
        >
            <motion.div
                animate={{
                    y: [0, 15, 0],
                }}
                transition={{
                    duration: 12,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                }}
                style={{
                    width,
                    height,
                }}
                className="relative"
            >
                <div
                    className={`absolute inset-0 rounded-full bg-gradient-to-r to-transparent ${gradient} backdrop-blur-[2px] border-2 border-white/[0.15] shadow-[0_8px_32px_0_rgba(255,255,255,0.1)] after:absolute after:inset-0 after:rounded-full after:bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.2),transparent_70%)]`}
                />
            </motion.div>
        </motion.div>
    );
}

const features = [
    {
        icon: Headphones,
        title: "Fortlaufender Kundendienst",
        description: "Unser erfahrenes Team steht Ihnen kontinuierlich zur Verfügung und gewährleistet eine professionelle Betreuung während des gesamten Projekts.",
    },
    {
        icon: Clock,
        title: "Routinierte Abläufe",
        description: "Durch bewährte Prozesse und langjährige Erfahrung sorgen wir für effiziente und termingerechte Durchführung Ihrer Abbrucharbeiten.",
    },
    {
        icon: Star,
        title: "Erstklassiger Service",
        description: "Höchste Qualitätsstandards und persönliche Betreuung - wir setzen alles daran, Ihre Erwartungen zu übertreffen.",
    },
    {
        icon: Award,
        title: "Bestmögliche Qualität",
        description: "Wir garantieren Ihnen beste Ergebnisse durch modernste Technik, regelmäßige Schulungen und umfassende Qualitätskontrolle.",
    }
];

export function WhyUsSection() {
    const fadeUpVariants = {
        hidden: { 
            opacity: 0, 
            y: 80, 
            scale: 0.8,
            rotateX: 15,
            z: -50
        },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            rotateX: 0,
            z: 0,
            transition: {
                duration: 0.8,
                delay: 0.2,
                ease: [0.25, 0.46, 0.45, 0.94], // Ease-In-Out-Cubic
            },
        },
    } as const;

    return (
        <div className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#030303]">
            <div className="absolute inset-0 bg-gradient-to-br from-rose-500/[0.05] via-transparent to-black/[0.05] blur-3xl" />

            <div className="absolute inset-0 overflow-hidden">
                <ElegantShape
                    delay={0.3}
                    width={600}
                    height={140}
                    rotate={12}
                    gradient="from-rose-500/[0.15]"
                    className="left-[-10%] md:left-[-5%] top-[15%] md:top-[20%]"
                />

                <ElegantShape
                    delay={0.5}
                    width={500}
                    height={120}
                    rotate={-15}
                    gradient="from-black/[0.15]"
                    className="right-[-5%] md:right-[0%] top-[70%] md:top-[75%]"
                />

                <ElegantShape
                    delay={0.4}
                    width={300}
                    height={80}
                    rotate={-8}
                    gradient="from-amber-600/[0.15]"
                    className="left-[5%] md:left-[10%] bottom-[5%] md:bottom-[10%]"
                />

                <ElegantShape
                    delay={0.6}
                    width={200}
                    height={60}
                    rotate={20}
                    gradient="from-rose-500/[0.15]"
                    className="right-[15%] md:right-[20%] top-[10%] md:top-[15%]"
                />
            </div>

            <div className="relative z-10 container mx-auto px-4 md:px-6">
                <div className="max-w-6xl mx-auto">
                    <motion.div
                        custom={0}
                        variants={fadeUpVariants}
                        initial="hidden"
                        animate="visible"
                        className="text-center mb-16"
                    >
                        <h2 className="text-4xl sm:text-6xl md:text-7xl font-bold mb-6 md:mb-8 tracking-tight">
                            <span className="bg-clip-text text-transparent bg-gradient-to-r from-rose-400 via-white/90 to-white/70">
                                Warum wir
                            </span>
                        </h2>
                        <p className="text-lg sm:text-xl md:text-2xl text-white/70 mb-8 leading-relaxed font-light tracking-wide max-w-3xl mx-auto">
                            Sehen Sie selbst, warum wir der richtige Partner für Ihr Projekt sind.
                        </p>
                    </motion.div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {features.map((feature, index) => {
                            const IconComponent = feature.icon;
                            return (
                                <motion.div
                                    key={feature.title}
                                    custom={index + 1}
                                    variants={fadeUpVariants}
                                    initial="hidden"
                                    animate="visible"
                                    className="group"
                                >
                                    <motion.div 
                                        className="bg-white/[0.05] border border-white/[0.12] rounded-3xl backdrop-blur-sm h-full overflow-hidden group relative"
                                        whileHover={{ 
                                            scale: 1.05,
                                            y: -10,
                                            rotateY: 5,
                                            boxShadow: "0 25px 50px rgba(251, 113, 133, 0.15)"
                                        }}
                                        transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
                                    >
                                        <div className="flex flex-col items-center text-center h-full p-8 relative">
                                            <motion.div 
                                                className="absolute inset-0 bg-gradient-to-br from-rose-500/[0.05] to-transparent rounded-3xl"
                                                initial={{ opacity: 0 }}
                                                whileHover={{ opacity: 1 }}
                                                transition={{ duration: 0.3 }}
                                            />
                                            
                                            <motion.div 
                                                className="w-20 h-20 bg-gradient-to-r from-rose-500 via-rose-600 to-rose-700 rounded-2xl flex items-center justify-center mb-6 shadow-2xl relative z-10"
                                                whileHover={{ 
                                                    scale: 1.15,
                                                    rotate: 5,
                                                    boxShadow: "0 20px 40px rgba(251, 113, 133, 0.4)"
                                                }}
                                                transition={{ duration: 0.3 }}
                                            >
                                                <IconComponent className="w-10 h-10 text-white" />
                                            </motion.div>
                                            
                                            <motion.h3 
                                                className="text-2xl font-bold text-white mb-4 relative z-10"
                                                whileHover={{ 
                                                    color: "#fecaca",
                                                    x: 5
                                                }}
                                                transition={{ duration: 0.3 }}
                                            >
                                                {feature.title}
                                            </motion.h3>
                                            
                                            <motion.p 
                                                className="text-white/70 text-base leading-relaxed flex-grow relative z-10"
                                                whileHover={{ opacity: 1 }}
                                                transition={{ duration: 0.3 }}
                                            >
                                                {feature.description}
                                            </motion.p>
                                        </div>
                                    </motion.div>
                                </motion.div>
                            );
                        })}
                    </div>
                </div>
            </div>

            <div className="absolute inset-0 bg-gradient-to-t from-[#030303] via-transparent to-[#030303]/80 pointer-events-none" />
        </div>
    );
}
