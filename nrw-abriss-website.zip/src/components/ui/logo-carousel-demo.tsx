"use client";

import React from "react";
import { GradientHeading } from "@/components/ui/gradient-heading";
import { AnimatedLogoCarousel } from "@/components/ui/animated-logo-carousel";

export function LogoCarouselDemo() {
  return (
    <div className="space-y-8 py-24 bg-[#030303]">
      <div className="mx-auto flex w-full max-w-screen-lg flex-col items-center space-y-8">
        <div className="text-center">
          <GradientHeading variant="secondary" size="lg" className="text-white/60">
            Vertrauen Sie auf unsere Erfahrung
          </GradientHeading>
          <GradientHeading 
            size="xl" 
            className="bg-gradient-to-r from-orange-300 via-white/90 to-red-300 bg-clip-text text-transparent"
          >
            Unsere Kunden
          </GradientHeading>
        </div>

        <AnimatedLogoCarousel />
      </div>
    </div>
  );
}
