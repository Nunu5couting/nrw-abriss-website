"use client";

import React from "react";
import { motion } from "framer-motion";
import {
  FordIcon,
  FroebelIcon,
  DLRIcon,
  JumoIcon,
  LocoQuickenIcon,
  FriedrichWassermannIcon,
  NRWAbrissIcon,
} from "@/components/ui/nrwabriss-logos";

// Array mit den NRW Abriss Kundenlogos
const nrwAbrissLogos = [
  { name: "Ford", id: 1, img: FordIcon },
  { name: "Fröbel Kindergarten", id: 2, img: FroebelIcon },
  { name: "DLR Köln", id: 3, img: DLRIcon },
  { name: "Jumo Solingen", id: 4, img: JumoIcon },
  { name: "Loco Quicken", id: 5, img: LocoQuickenIcon },
  { name: "Friedrich Wassermann", id: 6, img: FriedrichWassermannIcon },
  { name: "NRW Abriss", id: 7, img: NRWAbrissIcon },
];

export function AnimatedLogoCarousel() {
  return (
    <div className="overflow-hidden relative w-full">
      <motion.div
        className="flex space-x-8"
        animate={{
          x: [0, -100 * nrwAbrissLogos.length],
        }}
        transition={{
          x: {
            repeat: Infinity,
            repeatType: "loop",
            duration: 20,
            ease: "linear",
          },
        }}
      >
        {/* Erste Reihe der Logos */}
        {nrwAbrissLogos.map((logo) => {
          const LogoComponent = logo.img;
          return (
            <div
              key={logo.id}
              className="flex-shrink-0 flex items-center justify-center"
            >
              <div className="bg-white/5 rounded-lg p-4 border border-white/10 hover:bg-white/10 transition-all duration-300">
                <LogoComponent className="h-16 w-24 md:h-20 md:w-32 object-contain" />
              </div>
            </div>
          );
        })}
        {/* Zweite Reihe der Logos für nahtlose Animation */}
        {nrwAbrissLogos.map((logo) => {
          const LogoComponent = logo.img;
          return (
            <div
              key={`duplicate-${logo.id}`}
              className="flex-shrink-0 flex items-center justify-center"
            >
              <div className="bg-white/5 rounded-lg p-4 border border-white/10 hover:bg-white/10 transition-all duration-300">
                <LogoComponent className="h-16 w-24 md:h-20 md:w-32 object-contain" />
              </div>
            </div>
          );
        })}
      </motion.div>
    </div>
  );
}






