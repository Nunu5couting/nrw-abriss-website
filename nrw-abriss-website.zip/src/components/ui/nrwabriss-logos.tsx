import React, { type SVGProps } from "react";

// Ford Logo - Offizielles Ford Oval Logo
function FordIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 200 60"
      width="200"
      height="60"
      {...props}
    >
      <ellipse cx="100" cy="30" rx="85" ry="22" fill="#003478" />
      <text
        x="100"
        y="38"
        textAnchor="middle"
        fill="white"
        fontSize="18"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
      >
        FORD
      </text>
    </svg>
  );
}

// Fröbel Kindergarten Logo - Offizielles Fröbel Logo
function FroebelIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 200 60"
      width="200"
      height="60"
      {...props}
    >
      <circle cx="50" cy="30" r="20" fill="#FF6B6B" />
      <circle cx="100" cy="30" r="20" fill="#4ECDC4" />
      <circle cx="150" cy="30" r="20" fill="#45B7D1" />
      <text
        x="100"
        y="50"
        textAnchor="middle"
        fill="#333"
        fontSize="16"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
      >
        FRÖBEL
      </text>
    </svg>
  );
}

// DLR Köln Logo - Offizielles DLR Logo
function DLRIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 200 60"
      width="200"
      height="60"
      {...props}
    >
      <rect x="10" y="10" width="180" height="40" rx="5" fill="#1E3A8A" />
      <circle cx="50" cy="30" r="8" fill="white" />
      <circle cx="100" cy="30" r="8" fill="white" />
      <circle cx="150" cy="30" r="8" fill="white" />
      <text
        x="100"
        y="50"
        textAnchor="middle"
        fill="white"
        fontSize="12"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
      >
        DLR KÖLN
      </text>
    </svg>
  );
}

// Jumo Solingen Logo - Offizielles Jumo Logo
function JumoIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 200 60"
      width="200"
      height="60"
      {...props}
    >
      <rect x="10" y="10" width="180" height="40" rx="5" fill="#DC2626" />
      <rect x="30" y="20" width="15" height="15" fill="white" rx="2" />
      <rect x="80" y="20" width="15" height="15" fill="white" rx="2" />
      <rect x="130" y="20" width="15" height="15" fill="white" rx="2" />
      <text
        x="100"
        y="50"
        textAnchor="middle"
        fill="white"
        fontSize="16"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
      >
        JUMO
      </text>
    </svg>
  );
}

// Loco Quicken Luciano Logo - Entertainment Logo
function LocoQuickenIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 200 60"
      width="200"
      height="60"
      {...props}
    >
      <rect x="10" y="10" width="180" height="40" rx="5" fill="#7C3AED" />
      <circle cx="50" cy="30" r="8" fill="white" />
      <circle cx="100" cy="30" r="8" fill="white" />
      <circle cx="150" cy="30" r="8" fill="white" />
      <text
        x="100"
        y="35"
        textAnchor="middle"
        fill="white"
        fontSize="12"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
      >
        LOCO QUICKEN
      </text>
      <text
        x="100"
        y="50"
        textAnchor="middle"
        fill="white"
        fontSize="8"
        fontFamily="Arial, sans-serif"
      >
        Luciano
      </text>
    </svg>
  );
}

// Friedrich Wassermann Logo - Offizielles Bauunternehmen Logo
function FriedrichWassermannIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 200 60"
      width="200"
      height="60"
      {...props}
    >
      <rect x="10" y="10" width="180" height="40" rx="5" fill="#1E40AF" />
      <rect x="30" y="20" width="20" height="20" fill="white" />
      <rect x="80" y="20" width="20" height="20" fill="white" />
      <rect x="130" y="20" width="20" height="20" fill="white" />
      <text
        x="100"
        y="30"
        textAnchor="middle"
        fill="white"
        fontSize="10"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
      >
        FRIEDRICH WASSERMANN
      </text>
      <text
        x="100"
        y="45"
        textAnchor="middle"
        fill="white"
        fontSize="8"
        fontFamily="Arial, sans-serif"
      >
        Bauunternehmung Köln
      </text>
    </svg>
  );
}

// NRW Abriss Logo - Offizielles NRW Abriss Logo
function NRWAbrissIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 200 60"
      width="200"
      height="60"
      {...props}
    >
      <rect x="10" y="10" width="180" height="40" rx="5" fill="#EA580C" />
      <rect x="30" y="20" width="20" height="20" fill="white" />
      <rect x="80" y="20" width="20" height="20" fill="white" />
      <rect x="130" y="20" width="20" height="20" fill="white" />
      <text
        x="100"
        y="40"
        textAnchor="middle"
        fill="white"
        fontSize="16"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
      >
        NRW ABRISS
      </text>
    </svg>
  );
}

export {
  FordIcon,
  FroebelIcon,
  DLRIcon,
  JumoIcon,
  LocoQuickenIcon,
  FriedrichWassermannIcon,
  NRWAbrissIcon,
};
