import { cn } from "@/lib/utils"
import { Avatar, AvatarImage } from "@/components/ui/avatar"

export interface TestimonialAuthor {
  name: string
  handle: string
  avatar: string
}

export interface TestimonialCardProps {
  author: TestimonialAuthor
  text: string
  href?: string
  className?: string
}

export function TestimonialCard({ 
  author,
  text,
  href,
  className
}: TestimonialCardProps) {
  const Card = href ? 'a' : 'div'
  
  return (
    <Card
      {...(href ? { href } : {})}
      className={cn(
        "flex flex-col rounded-2xl border border-white/[0.08]",
        "bg-white/[0.03] backdrop-blur-sm",
        "p-6 text-start sm:p-8",
        "hover:bg-white/[0.05] hover:border-white/[0.12]",
        "transition-all duration-300",
        className
      )}
    >
      <div className="flex items-center gap-4 mb-6">
        <Avatar className="h-14 w-14 border-2 border-white/[0.2]">
          <AvatarImage src={author.avatar} alt={author.name} />
        </Avatar>
        <div className="flex flex-col items-start">
          <h3 className="text-lg font-semibold leading-none text-white">
            {author.name}
          </h3>
          <p className="text-sm text-white/60 mt-1">
            {author.handle}
          </p>
        </div>
      </div>
      <div className="relative">
        <div className="absolute -top-2 -left-2 text-4xl text-red-500/20">&ldquo;</div>
        <p className="text-lg text-white/80 leading-relaxed relative z-10">
          {text}
        </p>
        <div className="absolute -bottom-2 -right-2 text-4xl text-red-500/20 rotate-180">&rdquo;</div>
      </div>
    </Card>
  )
}
