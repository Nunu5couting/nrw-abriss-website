'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, Check, X } from 'lucide-react'
import { supabase, isSupabaseConfigured } from '@/lib/supabase'

interface NewsletterFormProps {
  className?: string
}

export function NewsletterForm({ className = '' }: NewsletterFormProps) {
  const [email, setEmail] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError('')

    try {
      if (!isSupabaseConfigured) {
        // Demo mode - simulate newsletter subscription
        console.log('Demo mode: Newsletter subscription for:', email)
        await new Promise(resolve => setTimeout(resolve, 1000)) // Simulate API call
        setIsSubmitted(true)
        setEmail('')
        
        setTimeout(() => {
          setIsSubmitted(false)
        }, 5000)
        return
      }

      // Check if email already exists
      const { data: existingSubscriber } = await supabase
        .from('newsletter_subscribers')
        .select('email')
        .eq('email', email)
        .eq('is_active', true)
        .single()

      if (existingSubscriber) {
        setError('Diese E-Mail-Adresse ist bereits angemeldet.')
        setIsSubmitting(false)
        return
      }

      // Insert new subscriber
      const { data, error: insertError } = await supabase
        .from('newsletter_subscribers')
        .insert([
          {
            email: email,
            is_active: true
          }
        ])
        .select()

      if (insertError) {
        console.error('Error subscribing to newsletter:', insertError)
        setError('Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.')
      } else {
        console.log('Newsletter subscription successful:', data)
        setIsSubmitted(true)
        setEmail('')
        
        // Reset after 5 seconds
        setTimeout(() => {
          setIsSubmitted(false)
        }, 5000)
      }
    } catch (error) {
      console.error('Error subscribing to newsletter:', error)
      setError('Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <motion.div
      className={`bg-white/[0.05] border border-white/[0.12] rounded-2xl p-6 backdrop-blur-sm ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-gradient-to-r from-rose-500 to-rose-600 rounded-xl flex items-center justify-center">
          <Mail className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Newsletter abonnieren</h3>
          <p className="text-white/60 text-sm">Bleiben Sie über unsere neuesten Projekte informiert</p>
        </div>
      </div>

      {isSubmitted ? (
        <motion.div
          className="flex items-center gap-3 text-green-400"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Check className="w-5 h-5" />
          <span>Erfolgreich angemeldet! Vielen Dank.</span>
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Ihre E-Mail-Adresse"
              required
              className="w-full px-4 py-3 bg-white/[0.05] border border-white/[0.1] rounded-lg text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-transparent"
            />
          </div>

          {error && (
            <motion.div
              className="flex items-center gap-2 text-red-400 text-sm"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <X className="w-4 h-4" />
              <span>{error}</span>
            </motion.div>
          )}

          <motion.button
            type="submit"
            disabled={isSubmitting}
            className="w-full px-6 py-3 bg-gradient-to-r from-rose-500 to-rose-600 text-white font-semibold rounded-lg hover:from-rose-600 hover:to-rose-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Wird angemeldet...
              </>
            ) : (
              <>
                <Mail className="w-4 h-4" />
                Newsletter abonnieren
              </>
            )}
          </motion.button>
        </form>
      )}
    </motion.div>
  )
}
