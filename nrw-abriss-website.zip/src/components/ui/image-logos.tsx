import React from "react";
import Image from "next/image";

// Ford Logo - Verwendet das hochgeladene Bild
type LogoImageProps = { className?: string };

function FordIcon({ className }: LogoImageProps) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <Image
        src="/Ford_logo_flat.svg.png"
        alt="Ford Logo"
        width={120}
        height={40}
        className={"object-contain " + (className ?? "")}
      />
    </div>
  );
}

// Fröbel Kindergarten Logo - Verwendet das hochgeladene Bild
function FroebelIcon({ className }: LogoImageProps) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <Image
        src="/221101_FROE_Teaser_Logovorschau_Intranet_Phase4.jpg"
        alt="Fröbel Kindergarten Logo"
        width={120}
        height={40}
        className={"object-contain " + (className ?? "")}
      />
    </div>
  );
}

// DLR Köln Logo - Verwendet das hochgeladene SVG
function DLRIcon({ className }: LogoImageProps) {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-white rounded-lg p-2">
      <Image
        src="/DLR_Logo.svg"
        alt="DLR Köln Logo"
        width={120}
        height={40}
        className={"object-contain " + (className ?? "")}
      />
    </div>
  );
}

// Jumo Solingen Logo - Verwendet das hochgeladene Bild
function JumoIcon({ className }: LogoImageProps) {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-white rounded-lg p-2">
      <Image
        src="/images.png"
        alt="Jumo Logo"
        width={120}
        height={40}
        className={"object-contain " + (className ?? "")}
      />
    </div>
  );
}

// Loco Chicken Logo - Verwendet das hochgeladene Bild
function LocoQuickenIcon({ className }: LogoImageProps) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <Image
        src="/logo.png"
        alt="Loco Chicken Logo"
        width={120}
        height={40}
        className={"object-contain " + (className ?? "")}
      />
    </div>
  );
}

// Friedrich Wassermann Logo - Placeholder da kein spezifisches Bild
function FriedrichWassermannIcon() {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-r from-rose-500 to-red-600 rounded-lg p-2">
      <span className="text-white text-sm font-bold text-center">
        FRIEDRICH<br />WASSERMANN
      </span>
    </div>
  );
}

// NRW Abriss Logo - Placeholder da kein spezifisches Bild
function NRWAbrissIcon() {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-r from-rose-500 to-red-600 rounded-lg p-2">
      <span className="text-white text-sm font-bold text-center">
        NRW<br />ABRISS
      </span>
    </div>
  );
}

export {
  FordIcon,
  FroebelIcon,
  DLRIcon,
  JumoIcon,
  LocoQuickenIcon,
  FriedrichWassermannIcon,
  NRWAbrissIcon,
};


