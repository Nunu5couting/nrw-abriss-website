"use client";

import React from "react";
import {
  FordIcon,
  FroebelIcon,
  DLRIcon,
  JumoIcon,
  LocoQuickenIcon,
  FriedrichWassermannIcon,
  NRWAbrissIcon,
} from "@/components/ui/nrwabriss-logos";

// Array mit den NRW Abriss Kundenlogos
const nrwAbrissLogos = [
  { name: "Ford", id: 1, img: FordIcon },
  { name: "Fröbel Kindergarten", id: 2, img: FroebelIcon },
  { name: "DLR Köln", id: 3, img: DLRIcon },
  { name: "Jumo Solingen", id: 4, img: JumoIcon },
  { name: "Loco Quicken", id: 5, img: LocoQuickenIcon },
  { name: "Friedrich Wassermann", id: 6, img: FriedrichWassermannIcon },
  { name: "NRW Abriss", id: 7, img: NRWAbrissIcon },
];

export function StaticLogoGrid() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
      {nrwAbrissLogos.map((logo) => {
        const LogoComponent = logo.img;
        return (
          <div
            key={logo.id}
            className="flex items-center justify-center p-4 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-all duration-300"
          >
            <LogoComponent className="h-16 w-24 md:h-20 md:w-32 object-contain" />
          </div>
        );
      })}
    </div>
  );
}






