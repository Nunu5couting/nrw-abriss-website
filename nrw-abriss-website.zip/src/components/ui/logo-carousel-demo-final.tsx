"use client";

import React from "react";
import { GradientHeading } from "@/components/ui/gradient-heading";
import { LogoCarousel } from "@/components/ui/logo-carousel-original";
import {
  FordIcon,
  FroebelIcon,
  DLRIcon,
  JumoIcon,
  LocoQuickenIcon,
  FriedrichWassermannIcon,
  NRWAbrissIcon,
} from "@/components/ui/image-logos";

// Array mit den NRW Abriss Kundenlogos
const nrwAbrissLogos = [
  { name: "Ford", id: 1, img: FordIcon },
  { name: "Fröbel Kindergarten", id: 2, img: FroebelIcon },
  { name: "DLR Köln", id: 3, img: DLRIcon },
  { name: "Jumo Solingen", id: 4, img: JumoIcon },
  { name: "Loco Chicken", id: 5, img: LocoQuickenIcon },
  { name: "Friedrich Wassermann", id: 6, img: FriedrichWassermannIcon },
  { name: "NRW Abriss", id: 7, img: NRWAbrissIcon },
];

export function LogoCarouselDemo() {
  return (
    <div className="space-y-8 py-24 bg-[#030303]">
      <div className="mx-auto flex w-full max-w-screen-lg flex-col items-center space-y-8">
        <div className="text-center">
          <GradientHeading variant="secondary" size="lg" className="text-white/60">
            Vertrauen Sie auf unsere Erfahrung
          </GradientHeading>
          <GradientHeading 
            size="xl" 
            className="bg-gradient-to-r from-rose-400 via-white/90 to-white/70 bg-clip-text text-transparent"
          >
            Unsere Kunden
          </GradientHeading>
        </div>

        <LogoCarousel columnCount={3} logos={nrwAbrissLogos} />
      </div>
    </div>
  );
}
